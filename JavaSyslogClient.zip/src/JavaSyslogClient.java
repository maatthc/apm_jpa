import com.ice.syslog.*;

import java.io.*;

public class JavaSyslogClient {
	public static void main(String[] args) {
		String host, port, message;
		int facility = SyslogDefs.LOG_LOCAL0;
		host = "localhost";
		port = "514";
		message = "Test from the Syslog Java Client!";
		System.out.println( "Starting Syslog Object" );
		try {
			Syslog syslog = new Syslog (host, Integer.valueOf(port), "uselees", SyslogDefs.LOG_PERROR);
			syslog.syslog(SyslogDefs.LOG_LOCAL0, SyslogDefs.LOG_ALERT, message);
			syslog.close();
		}
		catch (SyslogException ex ){
			String emessage =
					"error executing syslog : " + ex.getMessage();
			System.err.println(emessage);
		}
	}

public static void usage(){
	System.out.println("Usage:");
	//String executable = new java.io.File(JavaSyslogClient.class.getProtectionDomain()
	//		  .getCodeSource()
	//		  .getLocation()
	//		  .getPath())
	//		.getName();
	//System.out.println(executable + " [< host: localhost>] [< port: 514>] [< facility: LOG_LOCAL0>] [<Message: Test from the Syslog Java Client!>]");
	System.out.println("");
	System.out.println("Where 'facility' is one of the following numbers: ");
	System.out.println("0 = LOG_KERN	 /* kernel messages */");
	System.out.println("1 = LOG_USER	 /* random user-level messages */");
	System.out.println("2 = LOG_MAIL	 /* mail system */");
	System.out.println("3 = LOG_DAEMON	 /* system daemons */");
	System.out.println("4 = LOG_AUTH	 /* security/authorization messages */");
	System.out.println("5 = LOG_SYSLOG	 /* messages generated internally by syslogd */");
	System.out.println("6 = LOG_LPR		 /* line printer subsystem */");
	System.out.println("7 = LOG_NEWS	 /* network news subsystem */");
	System.out.println("8 = LOG_UUCP	 /* UUCP subsystem */");
	System.out.println("9 = LOG_CRON	 /* clock daemon */");
}

}